
Mw=6
Rjb=10
Fdepth=5

T=0:0.01:2
for i=1:length(T)
lnY=GMM_Azores(T(i),Mw,Rjb,Fdepth)
result(i,1)=exp(lnY)*980 %in cm/s^2
end
%%plot
loglog(T,result,'lineWidth',3)
ylabel('PSA(cm/s^2)','FontName','Times New roman','Fontsize',12)
xlabel('Periods(s)','FontName','Times New roman','Fontsize',12)

